package com.cg.jpastart.entities;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Traineetest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		Trainee tr=new Trainee();
		Scanner sc=new Scanner(System.in);
		System.out.println("enter details Id");
		int id=sc.nextInt();
		System.out.println("enter trainee name");
		String str=sc.next();
		System.out.println("enter module name");
		String str1=sc.next();
		System.out.println("enter MPT marks");
		int mpt=sc.nextInt();
		System.out.println("enter MTT marks");
		int mtt=sc.nextInt();
		System.out.println("enter Assignment marks");
		int ass=sc.nextInt();
		
		tr.setDetails_id(id);
		tr.setTrainee_name(str);
		tr.setModule_name(str1);
		tr.setMpt_marks(mpt);
		tr.setMtt_marks(mtt);
		tr.setAssignment_marks(ass);
		tr.getsum(mpt, mtt, ass);
		em.persist(tr);
		em.getTransaction().commit();
		System.out.println("Added one student to database.");
		em.close();
		factory.close();
	}
}
